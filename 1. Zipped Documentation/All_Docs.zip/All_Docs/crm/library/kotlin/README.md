# Kotlin CRM common libraries

{% include [CodeRules](./docs/_coderules.md) %}
