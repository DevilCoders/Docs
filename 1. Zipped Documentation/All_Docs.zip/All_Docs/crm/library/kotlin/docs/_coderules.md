{% include [Project](./_project.md) %}

{% include [Naming](./_naming.md) %}

{% include [Processes](./_processes.md) %}
