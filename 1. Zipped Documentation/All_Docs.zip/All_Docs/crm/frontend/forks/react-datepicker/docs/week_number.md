`week_number` (component)
=========================


| name  | type  | default value  | description  |
|---|---|---|---|
|`ariaLabelPrefix`||||
|`onClick`|`func`|||
|`weekNumber` (required)|`number`|||