`portal` (component)
====================


| name  | type  | default value  | description  |
|---|---|---|---|
|`children`|`any`|||
|`portalId`|`string`|||