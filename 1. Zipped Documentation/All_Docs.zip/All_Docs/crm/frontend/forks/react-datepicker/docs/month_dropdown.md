`month_dropdown` (component)
============================


| name  | type  | default value  | description  |
|---|---|---|---|
|`dropdownMode` (required)|`enum("scroll"\|"select")`|||
|`locale`|`string`|||
|`month` (required)|`number`|||
|`onChange` (required)|`func`|||
|`useShortMonthInDropdown`|`bool`|||