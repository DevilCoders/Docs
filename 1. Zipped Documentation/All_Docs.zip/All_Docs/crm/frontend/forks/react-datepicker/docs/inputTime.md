`inputTime` (component)
=======================


| name  | type  | default value  | description  |
|---|---|---|---|
|`customTimeInput`|`element`|||
|`date`|`instanceOfDate`|||
|`onChange`|`func`|||
|`timeInputLabel`|`string`|||
|`timeString`|`string`|||