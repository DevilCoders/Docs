`month_year_dropdown` (component)
=================================


| name  | type  | default value  | description  |
|---|---|---|---|
|`date` (required)|`instanceOfDate`|||
|`dateFormat` (required)|`string`|||
|`dropdownMode` (required)|`enum("scroll"\|"select")`|||
|`locale`|`string`|||
|`maxDate` (required)|`instanceOfDate`|||
|`minDate` (required)|`instanceOfDate`|||
|`onChange` (required)|`func`|||
|`scrollableMonthYearDropdown`|`bool`|||