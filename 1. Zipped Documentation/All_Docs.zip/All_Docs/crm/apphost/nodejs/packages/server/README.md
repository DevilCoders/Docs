Apphost nodejs handlers
