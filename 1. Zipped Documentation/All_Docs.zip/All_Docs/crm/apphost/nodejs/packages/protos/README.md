## Arc genereted proto for js/ts.

### Update in nodejs root
```
npm run compile-proto
```

A few moments later... it will use ya make https://st.yandex-team.ru/FEI-19871.
