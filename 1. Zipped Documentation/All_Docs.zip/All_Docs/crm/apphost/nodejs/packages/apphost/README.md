This repo has sugar utils and wrap for @yandex-int/apphost-lib
