copy-past vendor for storybook -s param \
issue https://github.com/storybookjs/storybook/issues/714