1) [finder -> GO -> connect to server](https://jing.yandex-team.ru/files/jk76/image%20%286%29.png)
1) [smb://crmdev01.ld.yandex-team.ru/wwwcrm](https://jing.yandex-team.ru/files/jk76/image%20%287%29.png)
1) [логин/пароль](https://yav.yandex-team.ru/secret/sec-01fd9m6a4b215b7m84e8mp9xcm)

```
// запускаем в папке с проектом
bash deployDev.bash <space-number>

//собрать на space3 https://crmdev01.ld.yandex-team.ru/space3/index.html
bash deployDev.bash 3
```
