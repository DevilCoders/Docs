## Полезные ссылки для изучения системы

[Информация на wiki](https://wiki.yandex-team.ru/crm/)  
[По фронт на wiki](https://wiki.yandex-team.ru/crm/dev/ui/) ( Она уже устарела. Хочется всю информацию о проекте иметь в репозитории. Так будет удобнее. )  
[Документация для пользователей](https://doc.yandex-team.ru/CRM/crm-space/concepts/about.html)  

### По поддержке
[Заведение нового пользователя](https://wiki.yandex-team.ru/crm/dev/test/roles/#novyesotrudniki)
