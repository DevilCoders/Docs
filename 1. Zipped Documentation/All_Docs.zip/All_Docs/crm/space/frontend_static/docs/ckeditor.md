## Ckeditor
В приложении используется патченный ckeditor из большой почты. Репозиторий: https://github.com/yandex-ui/ckeditor.

Последние обновления:
* https://st.yandex-team.ru/CRM-6595
* https://st.yandex-team.ru/CRM-8673
