## Ссылки на инстансы
- https://crm.yandex-team.ru – прод
- https://tcrm-myt.yandex-team.ru – тест. Автоматически собирается новый релиз
- https://crmdev01.ld.yandex-team.ru/space/index.html – дев. Автоматически собирается дев ветка

### Дев машинки на которые можно что-то собрать, проверить, показать.
- https://crmdev01.ld.yandex-team.ru/space1/index.html
- https://crmdev01.ld.yandex-team.ru/space2/index.html
- https://crmdev01.ld.yandex-team.ru/space3/index.html
- https://crmdev01.ld.yandex-team.ru/space4/index.html