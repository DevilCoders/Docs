DEPRECATE: use components from lego2

Эта папка содержит общую точку входа для https://lego.yandex-team.ru/lego-on-react/. \
Каждый компонент может быть здесь доопределен нужной функциональностью, которой еще нет в lego.
