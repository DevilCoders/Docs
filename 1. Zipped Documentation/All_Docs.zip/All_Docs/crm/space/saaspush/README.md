# This repository was moved to Arcanum
https://a.yandex-team.ru/arc/trunk/arcadia/crm/crm-saaspush

## docker-saaspush
Docker for saaspush daemon. Delivery documents to saas index throw logbroker.

docker build -t registry.yandex.net/crm/saaspush:{version} .
docker push registry.yandex.net/crm/saaspush:{version}
