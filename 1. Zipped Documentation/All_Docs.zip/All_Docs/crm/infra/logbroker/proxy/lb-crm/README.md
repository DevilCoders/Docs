# LB to CRM Unified Agent config

Конфигурация unified agent, который читает сообщения из 1 топика и передаёт их в HTTP ручку

Документация на вики: https://wiki.yandex-team.ru/crm/dev/backend/newservices/nastrojjka-unified-agent-dlja-chtenija-iz-logbroker
