Please use the [documentation website](https://loic-sharma.github.io/BaGet/)
for the best browsing experience.