# Samples

Here you can find samples that show you how to use BaGet in your own projects:

* `BaGetWebApplication` - Embed BaGet into your own ASP.NET Core project
* `BaGet.Protocol.Samples.Tests` - Interact with a NuGet V3 API
