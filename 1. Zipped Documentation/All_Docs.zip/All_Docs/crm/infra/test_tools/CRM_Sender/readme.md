Документация по библиотекам

Unirest http://unirest.io/java.html
JsonPath https://github.com/jayway/JsonPath