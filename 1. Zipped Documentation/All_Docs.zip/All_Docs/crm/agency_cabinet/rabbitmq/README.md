# Собственный CI для образа Rabbitmq Alpaca
[Оригинальный проект](https://a.yandex-team.ru/arc/trunk/arcadia/smb/common/rmq/server)

## Образ Rabbitmq

Docker registry [registry.yandex.net/agency-cabinet/rabbitmq](https://registry.yandex.net/v2/agency-cabinet/rabbitmq/tags/list)

Sandbox resource [AGENCY_CABINET_RABBITMQ](https://a.yandex-team.ru/arc_vcs/sandbox/projects/agency_cabinet/resources)

Deploy [testing](https://deploy.yandex-team.ru/stages/agency-cabinet-backend-testing)



### [Детали настройки](https://a.yandex-team.ru/arc/trunk/arcadia/smb/common/rmq/server#detali-nastrojki)
