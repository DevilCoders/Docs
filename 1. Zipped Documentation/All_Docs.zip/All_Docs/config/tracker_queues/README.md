[Документация по конфигурации интеграции со стартреком](https://docs.yandex-team.ru/arcanum/pr/tracker)
