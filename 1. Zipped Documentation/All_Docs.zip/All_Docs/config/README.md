# Common arcadia configuration files
## Release branches configs
https://a.yandex-team.ru/arc_vcs/config/branches

## Tracker queues settings
https://a.yandex-team.ru/arc_vcs/config/tracker_queues
