Пакет портирован из git https://github.yandex-team.ru/devtools/python-netconfig (CSADMIN-37850 + DEVTOOLSSUPPORT-10527).

В 20.04(ubuntu focal) нет python2 библиотек. Чтобы не тянуть лишнее, было решено сделать статический бинарник. 1
