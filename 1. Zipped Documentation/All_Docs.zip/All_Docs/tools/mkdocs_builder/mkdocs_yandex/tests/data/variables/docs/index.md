{% if version > '1' %}
This should appear in result
{% else %}
And this should not
{% endif %}