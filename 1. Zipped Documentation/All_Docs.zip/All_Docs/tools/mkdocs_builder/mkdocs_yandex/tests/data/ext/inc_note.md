# Some more about inclusion

**Some text before**

{% include 'includes/four.md' %}

_And some text after_
