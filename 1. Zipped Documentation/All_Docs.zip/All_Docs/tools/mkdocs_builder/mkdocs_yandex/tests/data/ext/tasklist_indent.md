# Task List

- [X] item 1
  * [X] item A
  * [ ] item B
    more text
    + [x] item a
    + [ ] item b
    + [x] item c
    * [X] item C
- [ ] item 2
- [ ] item 3

# Mixed Lists

- item 1
  * [X] item A
  * [ ] item B
    more text
    1. item a
    2. item b
    3. item c
  * [X] item C
- item 2
- item 3

# Really Mixed Lists

- item 1
  * [X] item A
  - item B
    more text
    1. item a
    + item b
    + [ ] item c
  3. item C
2. item 2
- [X] item 3

# Test Tasklists in Subparagraphs

- [X] item 1

  - [X] item A

  - item a

# Test Tasklists Spanning Multiple Lines

 * [ ] The text on this line will be rendered, and the text on the
   second line should work as well.
 * [ ] It should also still work if you do any kind of
   special content.  For instance, *right here* it should still continue
   working.  And using `preformatted` or some
   other type of content should work too.