!!! info
    This will raise a syntax deprecation error
