# sandboxctl 
This project try to implement basic CLI for [sandbox](https://wiki.yandex-team.ru/sandbox)

- [Intro](docs/index.md)
- [Quickstart](docs/usage.md)

