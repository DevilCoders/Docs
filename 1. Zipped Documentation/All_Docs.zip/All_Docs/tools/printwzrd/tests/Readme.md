Инструкции к тесту [тут](https://a.yandex-team.ru/arc/trunk/arcadia/search/wizard/test_responses)
