A tool for translating cURL requests (from Chromium-based browsers developer tools)
to 'ab' (Apache Benchmark).

Script origin: https://gist.github.com/ctolsen/5679e874719de7500a0b
