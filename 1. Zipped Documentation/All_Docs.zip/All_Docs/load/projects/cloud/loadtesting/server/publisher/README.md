Copied from:

load/projects/lunapark/www/api/views/jobtrailpush.py
load/projects/lunapark/www/common/util/clients.py

Can't reuse directly because lunapark is not `ya.make`-ed
