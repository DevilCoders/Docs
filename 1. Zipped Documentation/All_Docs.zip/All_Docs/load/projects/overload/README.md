# Overload

a performance analytics service

## Deployment
### Local env
Db settings for local testing are stored in `docker-compose.yml`.
To deploy databases for local testing, run
```
docker-compose up
```
Please note that databases created are empty so migrations should be run for propagating data.