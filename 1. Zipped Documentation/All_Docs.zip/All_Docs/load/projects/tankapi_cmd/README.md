# yatank-internal-api-client
tankapi client adapted to tank >= 1.13.0

init test on tank:
tankapi-cmd -t tank.hostname -c load.ini -o "options" -f file
