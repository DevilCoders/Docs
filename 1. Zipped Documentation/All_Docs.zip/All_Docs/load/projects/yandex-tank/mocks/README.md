Mocks to test & develop various tank components
