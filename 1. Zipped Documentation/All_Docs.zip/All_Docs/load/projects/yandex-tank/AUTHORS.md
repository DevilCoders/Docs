The following authors have created the source code of "Yandex.Tank" published and distributed by YANDEX LLC as the owner:

Alexey Lavrenuke <direvius@gmail.com>  
Andrey Pohilko <apc@apc.kg>
Timur Torubarov <netort@yandex-team.ru>
Oles Pisarenko <doctornkz@yandex.ru>
Nurlan Nugumanov <nnugumanov@gmail.com>
Mikhail Epikhin <schizophrenia@yandex-team.ru>
Dmitriy Kuznetsov <kuznetsov.d.p@gmail.com>
Andrey Sekretenko <numpor@yandex-team.ru>
Andrew Grigorev <andrew@ei-grad.ru>
Gregory Komissarov <gregory.komissarov@gmail.com>
Mikhail Dyomin <f2nd@yandex-team.ru>
Ilya Krylov <krylov@corp.sputnik.ru>
Alexey Tishkov <odin450@gmail.com>
Andrey Osipov <mekagem@gmail.com>
zaratustra <kastolom@gmail.com>
Alexander Shorin <kxepal@gmail.com>
Alexey Kirpichnikov <alex.kirp@gmail.com>
Andrew Kulakov <avk@8xx8.ru>
Andrew Osipov <mekagem@gmail.com>
Anton <xecu91@gmail.com>
Fadi Hadzh <fdhadzh@gmail.com>
Gleb E Goncharov <gongled@gongled.ru>
Igor Shishkin <me@teran.ru>
Kirill SIbirev <l0kix2@gmail.com>
Konstantin Shalygin <k0ste@cn.ru>
Leonid Evdokimov <leon@darkk.net.ru>
Max Taldykin <jorpic@gmail.com>
Oleg Alistratov <wmute@yandex-team.ru>
Oleg Klimin <oleg_kl@mail.ru>
Sergey Melnik <admin.sa@gmail.com>
Vasily Chekalkin <bacek@yandex-team.ru>
Victor Ashik <victor@ashik.ru>
Vladimir Evgrafov <evgrafov.vladimir@gmail.com>
Yuriy Syrovetskiy <cblp@cblp.su>
kshcherban <k.scherban@gmail.com>
Oleg Klimin <oleg_kl@mail.ru>
Alexander Artemenko <svetlyak.40wt@gmail.com>
Maxim Bublis <satori@dropbox.com>
