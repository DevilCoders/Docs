# volta-backend
stores meta information on jobs and data and 
provides REST-like api for those things
django

[Wiki doc](https://wiki.yandex-team.ru/Luna/)