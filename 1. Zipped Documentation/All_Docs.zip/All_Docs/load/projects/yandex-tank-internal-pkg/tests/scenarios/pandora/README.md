# Исходники для custom пандоры
Для теста configs/pandora_2.yml используется отдельный бинарь пандоры
сам бинарь лежит тут https://storage-int.mds.yandex.net/get-load-ammo/15349/996ff372dbf7442ba52f7b751f17ec24
из этих исходников можно собрать заново.
