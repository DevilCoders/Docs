# yatank-internal-api
old internal tankapi adapted to tank >= 1.7

default port: 8083

to run tests: 

to restart: service tankapi restart
