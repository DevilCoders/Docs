# ModelInfoMatcher

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | identifier of the matcher | [optional] 
**model_info_id** | **str** | identifier of model info | [optional] 
**model_re** | **str** | the regexp filter that represent model | [optional] 
**rack_code** | **str** | rack code | [optional] 
**soft_id** | **str** | id of the soft | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

