# Match

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**matcher** | [**Matcher**](Matcher.md) |  | [optional] 
**softs** | [**list[Soft]**](Soft.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

