# Soft

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | identifier of the soft | [optional] 
**model_info** | [**ModelInfo**](ModelInfo.md) |  | [optional] 
**parent_id** | **str** | identifier of parent soft version | [optional] 
**version** | **str** | name of the soft | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

