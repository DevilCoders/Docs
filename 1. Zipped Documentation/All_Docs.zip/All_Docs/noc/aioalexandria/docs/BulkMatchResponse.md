# BulkMatchResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fqdns** | [**list[Match]**](Match.md) |  | [optional] 
**models** | [**list[Match]**](Match.md) |  | [optional] 
**object_ids** | [**list[Match]**](Match.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

