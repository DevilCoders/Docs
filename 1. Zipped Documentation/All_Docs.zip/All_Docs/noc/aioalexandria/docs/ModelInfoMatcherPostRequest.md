# ModelInfoMatcherPostRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**model_info_id** | **str** | identifier of model info | [optional] 
**model_re** | **str** | the regexp filter that represent model | [optional] 
**next_id** | **str** | identifier of the next matcher | [optional] 
**rack_code** | **str** | rack code | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

