# Matcher

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**category** | **str** | the matcher category, like default soft, recommended, dangerous or other. | [optional] 
**id** | **str** | identifier of the matcher | [optional] 
**model_re** | **str** | the regexp filter that represent model | [optional] 
**rack_code** | **str** | rack code | [optional] 
**soft_ids** | **list[str]** | identifiers of soft | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

