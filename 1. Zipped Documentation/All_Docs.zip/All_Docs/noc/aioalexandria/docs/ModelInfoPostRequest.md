# ModelInfoPostRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**check_sum** | **str** | check sum of archive file | [optional] 
**description** | **str** | description | [optional] 
**image_url** | **str** | url of image | [optional] 
**license** | **str** | license file | [optional] 
**patch_archive** | **str** | filename of the patch | [optional] 
**soft_archive** | **str** | filename of the soft | [optional] 
**soft_id** | **str** | id of the soft | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

