# Metapackages for Traffic Team repos configuration

*Note*: please use `_generate.py` script for `.json` files regeneration:

```
$ python3 _generate.py --pkg
```

Also you can generate shell commands to dmove repo packages from unstable to stable:

```
$ python3 _generate.py --gen-dmove --version 1.0.0-example-version
```
