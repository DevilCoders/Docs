--
--

lxs - auxiliary processing for cdn containers fw managment and network
      configuration (1) networking (2) firewalling (3) mpls scheme
