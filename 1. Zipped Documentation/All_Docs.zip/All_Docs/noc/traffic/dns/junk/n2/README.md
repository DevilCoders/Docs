#
#
#

n2 - control plane for ntp
