#
#
#

* syncing ipmi.yandex.net zone via command line in dry-run mode
  for yp and classical modes:

  [~] e2 sync --debug --dry-run --yp
  [~] e2 sync --debug --dry-run --classic

* adding one more objects classes w.r.t [2]

[1] https://test.bot.yandex-team.ru/api/view.php?name=view_dns_ipmi_v2&format=json
[2] https://st.yandex-team.ru/TRAFFIC-11542
