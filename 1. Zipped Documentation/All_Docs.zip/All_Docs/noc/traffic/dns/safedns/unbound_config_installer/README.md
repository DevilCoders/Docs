Unbound config installer
====

Helper script to generate Unbound configs and setup dirs/permissions/links
Currently executed by https://a.yandex-team.ru/arc/trunk/arcadia/noc/traffic/dns/safedns/misc/init_box while initializing a SafeDNS container
