nginx
=====

nginx module to inject information to distributives