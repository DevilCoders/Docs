## Script checks
[Требования к файлам проверок](https://docs.yandex-team.ru/juggler/client/bundles#requirements)
