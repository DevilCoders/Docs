Unfortunately, yandex repo has no clear owner and no repo-yandex-focal-stable package.

So, instead of owning repo-yandex-focal set of packages and according to local "best" practices, I made a crutch.
