== Firewall host macro monitoring

Monitors discrepancies between host macro and other information provider.

Currently supported:

* HBF (as macro host list provider)
* RackTables (search by RackCode)

See example config in `deb/config.yaml.example`.
