Based on Solo.

How to use:

1. `ya make` to build a binary
2. `./solo` to review changes
3. `./solo --apply-changes` to apply changes

Normally OAuth token for Solomon will be necessary (for CI), but SSH key in the agent will do.
