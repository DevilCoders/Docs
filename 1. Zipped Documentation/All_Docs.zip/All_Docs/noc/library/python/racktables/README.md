General functions from racktables to use on rackatble users side.
