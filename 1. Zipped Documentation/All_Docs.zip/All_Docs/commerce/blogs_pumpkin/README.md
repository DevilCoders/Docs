# blogs_pumpkin 🎃

Тыква [API Яндекс.Блогов](https://pages.github.yandex-team.ru/yablogs/yablogs-api-docs/v1/)

## Основные комманды

### Собрать бинарник

```
make build
```

### Запустить тесты

```
make test
```

### Запустить сервер

```
make run
```

### Собрать и запушить Docker-образ

```
make publish
```
