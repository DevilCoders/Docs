# adv-source [![Build Status](https://drone.yandex-team.ru/api/badges/advertising/adv-source/status.svg)](https://drone.yandex-team.ru/advertising/adv-source)
Внешние ресурсы для ADV

### Для разработки
```bash
npm i && npm run dev
```
