# expert-cron [![Build Status](https://drone.yandex-team.ru/api/badges/expert/expert-cron/status.svg)](https://drone.yandex-team.ru/expert/expert-cron)

### Приложение для запуска регулярных тасок
