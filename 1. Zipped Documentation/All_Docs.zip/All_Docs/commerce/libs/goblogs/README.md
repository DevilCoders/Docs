# Yandex Blogs API Go Client [![GoDoc](https://godoc.org/a?status.svg)](https://godoc.yandex-team.ru/pkg/a.yandex-team.ru/commerce/libs/goblogs)

Go клиент для [Yandex Blogs REST API](https://pages.github.yandex-team.ru/yablogs/yablogs-api-docs/v1)
