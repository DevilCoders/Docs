[![Build Status](https://drone.yandex-team.ru/api/badges/toolbox/cm/status.svg)](https://drone.yandex-team.ru/toolbox/cm)
# Content management help service

## Начало работы
1. Ставим зависимости ``npm install --registry=http://npm.yandex-team.ru``
2. Запускаем magicdev ``npm run magic``

## Доступные команды
``npm start`` запуск приложения на localhost

``npm run magic`` запуск приложения в режиме локальной разработки (см. magicdev)

``npm run build`` сборка проекта в production режиме (``NODE_ENV=production``)

> Powered by [Reactive-Stub](https://github.yandex-team.ru/reactive-stub/generator-reactive-stub) v1.3.1 and unicorns
