# proctoring-no-cookie [![Build Status](https://drone.yandex-team.ru/api/badges/expert/proctoring-no-cookie/status.svg)](https://drone.yandex-team.ru/expert/proctoring-no-cookie)

### Сервис для запуска скрипта подрядчика на бескуковом домене

Для локального запуска на https при первом запуске выполнить команду:
```bash
npm run local-cert
```
