# pipelines-cli

Cli for python-pipelines-api

usage example:

```bash    
pipelines-cli --env testing launch oebs other title="This a test event" start="2017-05-26 12:34:56+03:00" end="$(date --rfc-3339=seconds)"
```

