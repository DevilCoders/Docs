# paysys/sre/tools/deploy/sidecars

Well known sidecars:
* Nginx
* Nginx + SSL
* Solomon-agent - configs only, based on hot/billing/scripts/solomon
* Jaeger-agent - see hot/billing/scripts/jaeger
