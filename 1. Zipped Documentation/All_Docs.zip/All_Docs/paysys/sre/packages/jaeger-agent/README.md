Собрать пакет:
```
ya package --debian --key <gpg key> jaeger_package.json
```
