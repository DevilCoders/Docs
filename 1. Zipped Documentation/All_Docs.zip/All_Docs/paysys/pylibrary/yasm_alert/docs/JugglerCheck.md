# JugglerCheck

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**notifications** | [**list[JugglerCheckNotifications]**](JugglerCheckNotifications.md) |  | [optional] 
**aggregator_kwargs** | [**JugglerCheckAggregatorKwargs**](JugglerCheckAggregatorKwargs.md) |  | [optional] 
**flaps** | [**JugglerCheckFlaps**](JugglerCheckFlaps.md) |  | [optional] 
**service** | **str** |  | [optional] 
**aggregator** | **str** |  | [optional] 
**host** | **str** |  | [optional] 
**children** | [**list[JugglerCheckChildren]**](JugglerCheckChildren.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


