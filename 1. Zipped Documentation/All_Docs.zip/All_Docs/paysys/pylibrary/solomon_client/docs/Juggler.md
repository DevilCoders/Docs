# Juggler

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **str** | Mustache template, by default default template | [optional] 
**host** | **str** | Mustache template, by default solomon-alert | [optional] 
**service** | **str** | Mustache template, by default {{alert.id}} | [optional] 
**tags** | **list[str]** | Mustache template supportable list of tags for event | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

