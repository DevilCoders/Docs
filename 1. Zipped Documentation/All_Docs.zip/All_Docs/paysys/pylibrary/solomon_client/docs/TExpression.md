# TExpression

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program** | **str** | contains expression to evaluate | [optional] 
**check_expression** | **str** | TExpression that as a result evaluation should return boolean value, where true it&#x27;s ALARM, false it&#x27;s OK. TExpression can use variable from program. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

