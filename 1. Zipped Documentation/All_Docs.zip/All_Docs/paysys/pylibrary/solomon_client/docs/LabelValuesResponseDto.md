# LabelValuesResponseDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**labels** | [**list[LabelValuesDto]**](LabelValuesDto.md) |  | [optional] 
**max_count** | **int** |  | [optional] 
**sensors_count_by_cluster** | **dict(str, int)** |  | [optional] 
**total_count** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

