# Webhook

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body_template** | **str** | Mustache template for body | [optional] 
**headers** | **dict(str, str)** | Additional headers that need inject to notification request | [optional] 
**url** | **str** | Url that will be use to POST request | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

