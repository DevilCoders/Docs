# ShardListItemDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cluster_id** | **str** |  | [optional] 
**cluster_name** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**project_id** | **str** |  | [optional] 
**service_id** | **str** |  | [optional] 
**service_name** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

