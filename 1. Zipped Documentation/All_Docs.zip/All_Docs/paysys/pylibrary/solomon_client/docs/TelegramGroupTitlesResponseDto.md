# TelegramGroupTitlesResponseDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group_title** | **list[str]** |  | [optional] 
**request_status** | **str** |  | [optional] 
**status_message** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

