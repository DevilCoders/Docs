# UrlDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ignore_ports** | **bool** |  | [optional] 
**labels** | **list[str]** |  | [optional] 
**url** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

