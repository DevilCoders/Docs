# YpDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cluster** | **str** |  | [optional] 
**labels** | **list[str]** |  | [optional] 
**pod_set_id** | **str** |  | [optional] 
**tvm_label** | **str** |  | [optional] 
**yp_label** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

