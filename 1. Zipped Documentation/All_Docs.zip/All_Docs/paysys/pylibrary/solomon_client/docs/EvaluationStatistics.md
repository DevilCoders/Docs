# EvaluationStatistics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alarm** | **int** |  | [optional] 
**error** | **int** |  | [optional] 
**no_data** | **int** |  | [optional] 
**ok** | **int** |  | [optional] 
**warn** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

