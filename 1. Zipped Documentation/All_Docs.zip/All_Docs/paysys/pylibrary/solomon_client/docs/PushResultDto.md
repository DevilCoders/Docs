# PushResultDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**PushResultDto**](PushResultDto.md) |  | [optional] 
**error_message** | **str** |  | [optional] 
**sensors_processed** | **int** |  | [optional] 
**status** | **str** |  | [optional] 
**status_code** | **str** |  | [optional] 
**status_code_value** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

