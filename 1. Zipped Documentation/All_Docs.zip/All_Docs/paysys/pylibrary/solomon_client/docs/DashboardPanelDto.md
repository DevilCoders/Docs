# DashboardPanelDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**colspan** | **int** |  | [optional] 
**markdown** | **str** |  | [optional] 
**rowspan** | **int** |  | [optional] 
**subtitle** | **str** |  | [optional] 
**title** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**url** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

