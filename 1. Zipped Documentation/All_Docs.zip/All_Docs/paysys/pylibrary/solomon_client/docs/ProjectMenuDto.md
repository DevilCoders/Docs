# ProjectMenuDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** |  | [optional] 
**created_by** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**items** | [**list[MenuItemDto]**](MenuItemDto.md) |  | [optional] 
**updated_at** | **datetime** |  | [optional] 
**updated_by** | **str** |  | [optional] 
**version** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

