# ChannelConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**notify_about_statuses** | **list[str]** | Set of statuses to notify about | 
**repeat_delay_secs** | **int** | Repeat notification delay in seconds. Zero means no repeating | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

