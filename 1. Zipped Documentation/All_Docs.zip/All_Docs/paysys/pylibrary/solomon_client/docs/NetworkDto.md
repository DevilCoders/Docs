# NetworkDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**labels** | **list[str]** |  | [optional] 
**network** | **str** |  | [optional] 
**port** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

