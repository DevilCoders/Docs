# Sms

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**login** | **str** | User login that should receive SMS notifications, will be use default phone from passport | 
**phone** | **str** | Phone number that should receive SMS notifications | 
**text_template** | **str** | Mustache template for SMS. It&#x27;s optional parameter | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

