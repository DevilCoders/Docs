# QloudGroupDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application** | **str** |  | [optional] 
**component** | **str** |  | [optional] 
**deployment** | **str** |  | [optional] 
**environment** | **str** |  | [optional] 
**labels** | **list[str]** |  | [optional] 
**project** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

