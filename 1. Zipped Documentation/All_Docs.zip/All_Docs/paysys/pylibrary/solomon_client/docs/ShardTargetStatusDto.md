# ShardTargetStatusDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dc** | **str** |  | [optional] 
**host** | **str** |  | [optional] 
**last_content_type** | **str** |  | [optional] 
**last_error** | **str** |  | [optional] 
**last_fetch_duration_millis** | **int** |  | [optional] 
**last_fetch_time** | **datetime** |  | [optional] 
**last_response_bytes** | **int** |  | [optional] 
**last_sensors_overflow** | **int** |  | [optional] 
**last_sensors_parsed** | **int** |  | [optional] 
**last_status** | **str** |  | [optional] 
**url** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

