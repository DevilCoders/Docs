# ProjectStatistics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**evaluation_summary** | [**EvaluationStatistics**](EvaluationStatistics.md) |  | 
**notification_summary** | [**NotificationStatistics**](NotificationStatistics.md) |  | 
**alerts_count** | **int** | Alerts count in project | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

