# MenuItemDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**children** | [**list[MenuItemDto]**](MenuItemDto.md) |  | [optional] 
**selectors** | **str** |  | [optional] 
**title** | **str** |  | [optional] 
**url** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

