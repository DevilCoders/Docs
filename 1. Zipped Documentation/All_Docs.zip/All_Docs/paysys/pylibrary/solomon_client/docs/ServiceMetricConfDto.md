# ServiceMetricConfDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aggr_rules** | [**list[AggrRuleDto]**](AggrRuleDto.md) |  | [optional] 
**priority_rules** | [**list[PriorityRuleDto]**](PriorityRuleDto.md) |  | [optional] 
**raw_data_mem_only** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

