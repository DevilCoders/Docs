# CloudSms

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**iam_recipients** | **list[str]** | List of iam ids that should receive notifications | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

