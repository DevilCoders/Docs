# Method

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | [**Email**](Email.md) |  | [optional] 
**juggler** | [**Juggler**](Juggler.md) |  | [optional] 
**webhook** | [**Webhook**](Webhook.md) |  | [optional] 
**sms** | [**Sms**](Sms.md) |  | [optional] 
**telegram** | [**Telegram**](Telegram.md) |  | [optional] 
**cloud_email** | [**CloudEmail**](CloudEmail.md) |  | [optional] 
**cloud_sms** | [**CloudSms**](CloudSms.md) |  | [optional] 
**ya_chats** | [**YaChats**](YaChats.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

