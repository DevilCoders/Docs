# AlertExplainEvaluation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**AlertEvaluationStatusDto**](AlertEvaluationStatusDto.md) |  | 
**series** | [**list[AlertTimeSeries]**](AlertTimeSeries.md) | Time series that was use during check evaluation status | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

