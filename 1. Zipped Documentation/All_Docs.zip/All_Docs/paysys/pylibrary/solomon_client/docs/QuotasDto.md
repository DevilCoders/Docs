# QuotasDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max_file_sensors** | **int** |  | [optional] 
**max_mem_sensors** | **int** |  | [optional] 
**max_response_size_mb** | **int** |  | [optional] 
**max_sensors_per_url** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

