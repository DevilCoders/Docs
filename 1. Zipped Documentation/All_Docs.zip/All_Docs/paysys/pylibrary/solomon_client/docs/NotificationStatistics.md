# NotificationStatistics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**absent_notification_channel** | **int** |  | [optional] 
**error** | **int** |  | [optional] 
**invalid_request** | **int** |  | [optional] 
**permission_denied** | **int** |  | [optional] 
**resource_exhausted** | **int** |  | [optional] 
**retry_error** | **int** |  | [optional] 
**success** | **int** |  | [optional] 
**unknown** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

