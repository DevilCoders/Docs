# MessageLite

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**default_instance_for_type** | [**MessageLite**](MessageLite.md) |  | [optional] 
**initialized** | **bool** |  | [optional] 
**parser_for_type** | [**ParserMessageLite**](ParserMessageLite.md) |  | [optional] 
**serialized_size** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

