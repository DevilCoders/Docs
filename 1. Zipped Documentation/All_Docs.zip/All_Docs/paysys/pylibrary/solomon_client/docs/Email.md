# Email

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content_template** | **str** | Mustache template for email body, if not specified will be use global template | [optional] 
**recipients** | **list[str]** | List of email&#x27;s that should receive notifications | 
**subject_template** | **str** | Mustache template for subject attribute of email, if not specified will be use global template | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

