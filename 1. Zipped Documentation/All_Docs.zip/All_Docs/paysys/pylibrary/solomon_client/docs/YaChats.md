# YaChats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group_id** | **str** | Id of the group chat | [optional] 
**login** | **str** | Staff login | [optional] 
**text_template** | **str** | Mustache template for yaChats. It&#x27;s optional parameter | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

