# NannyGroupDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cfg_group** | **list[str]** |  | [optional] 
**labels** | **list[str]** |  | [optional] 
**port_shift** | **int** |  | [optional] 
**service** | **str** |  | [optional] 
**use_fetched_port** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

